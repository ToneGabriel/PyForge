.. cmake-module:: ../../Modules/FindGTest.cmake
