.. cmake-module:: ../../Modules/FindOpenSP.cmake
