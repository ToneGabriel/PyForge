#include <string>


void foo(const std::string&);
