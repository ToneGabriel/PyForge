#include "test_lib.h"
#include "lib.h"
#include "c_lib.h"


void foo(const std::string& s)
{
    print(s);
    print_c(s.c_str());
}
