#include "test_lib.h"


int main()
{
    foo("Hello World!");

    return 0;
}