#include "lib.h"
#include <iostream>


void print(const std::string& s)
{
    std::cout << s << '\n';
}
