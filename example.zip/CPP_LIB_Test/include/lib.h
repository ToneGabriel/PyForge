#include <string>

void print(const std::string&);
