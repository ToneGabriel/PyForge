#include "c_core.h"

EXTERN_C C_LIB_DLL_ATTR void print_c(const char* const);
