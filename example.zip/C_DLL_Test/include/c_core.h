#pragma once

#ifdef _WIN32
#   ifdef CUSTOM_CMAKE_DLL_EXPORT_MODE
#       define C_LIB_DLL_ATTR __declspec(dllexport)
#   else
#       define C_LIB_DLL_ATTR __declspec(dllimport)
#   endif
#else
#   define C_LIB_DLL_ATTR
#endif


// Need extern "C" when linking to this from C++ project
#ifdef __cplusplus
#   define EXTERN_C extern "C"
#else
#   define EXTERN_C
#endif
