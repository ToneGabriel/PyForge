#include "c_lib.h"
#include <stdio.h>


void print_c(const char* const s)
{
    printf("%s\n", s);
}
